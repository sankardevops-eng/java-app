# Bus-Tracking-Parent
Parent Android app for School Bus Tracking System Project.
<h3>Features</h3>
<ul>
<li>Login</li>
<li>See Profile</li>
<li>List of Kids</li>
<li>Arriving bus status</li>
<li>Recent Rides</li>
<li>Active Rides</li>
<li>Setting</li>
<li>Upload Photo</li>
<li>Add Home Gps</li>
</ul>
<br/>
<b>ScreenShot.</b>
<div>
 <img src="https://github.com/Rjtsahu/Bus-Tracking-Parent/blob/master/shot_parent_1.png" style="width:450;height:560;margin-left:40px;"/>
 </div>
 <div>
 <img src="https://github.com/Rjtsahu/Bus-Tracking-Parent/blob/master/shot_parent_2.png" style="width:450;height:560;margin-left:40px;"/>
 </div>
